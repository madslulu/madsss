<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="active" href="index.php">Home</a></li>
          <li><a class="" href="about.php">About Us</a></li>
          <li><a class="" href="terminal.php">Terminals</a></li>
          <li><a class="" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
          <li><a class="" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <section class="hero">
          <div class="container content">
            <span class="badge">Since 1993</span>
            <h1>Safe & Reliable Trips to Metro Manila and Mindoro</h1>
            <p class="sub">Comfortable buses, friendly service, and routes that get you there on time.</p>
            <div class="actions">
              <a href="book.php" class="btn">Book Now</a>
              <a href="routeschedule.php" class="btn btn-outline">See Routes & Schedules</a>
            </div>
          </div>
        </section>
        <section class="section">
          <div class="container grid grid-2">
            <div class="card">
              <h3 class="headline">About Dimple Star</h3>
              <p class="muted">Serving commuters for decades with a commitment to safety and reliability.</p>
              <a class="btn btn-outline" href="about.php">Learn more</a>
            </div>
            <div class="card">
              <h3 class="headline">Contact Us</h3>
              <p class="muted">Phone: 0929 209 0712<br>Block 1 Lot 10, Southpoint Subd., Banay-Banay, Cabuyao, Laguna</p>
              <a class="btn btn-outline" href="contact.php">Get in touch</a>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>