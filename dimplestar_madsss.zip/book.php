<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="" href="index.php">Home</a></li>
          <li><a class="" href="about.php">About Us</a></li>
          <li><a class="" href="terminal.php">Terminals</a></li>
          <li><a class="" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
          <li><a class="active" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <?php
          include 'php_includes/connection.php';
          include 'php_includes/book.php';
          session_start();
        ?>
        <section class="hero">
          <div class="container content">
            <h1>Book Your Trip</h1>
            <p class="sub">Choose your route, date, and bus type. Simple and fast.</p>
          </div>
        </section>
        <section class="section">
          <div class="container grid grid-2">
            <div class="card">
              <h3 class="headline">Booking Form</h3>
              <form class="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="actions" role="group" aria-label="Trip type">
                  <label><input style="margin-right:8px" type="radio" name="way" value="2" onclick="document.getElementById('returnDate').disabled=false"> Two Way</label>
                  <label><input style="margin-right:8px" type="radio" name="way" value="1" onclick="document.getElementById('returnDate').disabled=true" checked> One Way</label>
                </div>

                <div>
                  <label for="Origin">Origin</label>
                  <select id="Origin" name="Origin" required>
                    <option value="0">Select</option>
                    <option>San Lazaro</option><option>Espana</option><option>Alabang</option><option>Cabuyao</option>
                    <option>Naujan</option><option>Victoria</option><option>Pinamalayan</option><option>Gloria</option>
                    <option>Bongabong</option><option>Roxas</option><option>Mansalay</option><option>Bulalacao</option>
                    <option>Magsaysay</option><option>San Jose</option><option>Pola</option><option>Soccoro</option>
                  </select>
                </div>

                <div>
                  <label for="Destination">Destination</label>
                  <select id="Destination" name="Destination" required>
                    <option value="0">Select</option>
                    <option>San Lazaro</option><option>Espana</option><option>Alabang</option><option>Cabuyao</option>
                    <option>Naujan</option><option>Victoria</option><option>Pinamalayan</option><option>Gloria</option>
                    <option>Bongabong</option><option>Roxas</option><option>Mansalay</option><option>Bulalacao</option>
                    <option>Magsaysay</option><option>San Jose</option><option>Pola</option><option>Soccoro</option>
                  </select>
                </div>

                <div>
                  <label for="no_of_pass">No. of Passengers</label>
                  <input id="no_of_pass" type="number" name="no_of_pass" min="1" required>
                </div>

                <div class="grid" style="grid-template-columns:1fr 1fr; gap:12px">
                  <div>
                    <label for="Departure">Departure</label>
                    <input id="Departure" type="date" name="Departure" required>
                  </div>
                  <div>
                    <label for="Return">Return</label>
                    <input id="returnDate" type="date" name="Return" disabled>
                  </div>
                </div>

                <div>
                  <label for="bustype">Bus Type</label>
                  <select id="bustype" name="bustype" required>
                    <option value="0">Select</option>
                    <option value="Air Conditioned">Air Conditioned</option>
                    <option value="Ordinary">Ordinary</option>
                  </select>
                </div>

                <div class="actions">
                  <button class="btn" type="submit" id="submit" name="submit" value="Submit">Submit</button>
                  <a class="btn btn-outline" href="index.php">Cancel</a>
                </div>
              </form>
            </div>
            <div class="card">
              <h3 class="headline">Need help?</h3>
              <p class="muted">If you encounter issues while booking, call us at <strong>0929 209 0712</strong> or message us via the Contact page.</p>
              <div style="margin-top:12px">
                <strong>Date/Time:</strong>
                <div class="muted"><?php include_once("php_includes/date_time.php"); ?></div>
              </div>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>