<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="" href="index.php">Home</a></li>
          <li><a class="" href="about.php">About Us</a></li>
          <li><a class="active" href="terminal.php">Terminals</a></li>
          <li><a class="" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
          <li><a class="" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <section class="hero">
          <div class="container content">
            <h1>Terminals</h1>
            <p class="sub">Find our terminals and contact information.</p>
          </div>
        </section>
        <section class="section">
          <div class="container grid grid-2">
            <div class="card">
              <h3 class="headline">Metro Manila</h3>
              <p class="muted">San Lazaro, Espana, Alabang</p>
            </div>
            <div class="card">
              <h3 class="headline">Mindoro</h3>
              <p class="muted">Naujan, Victoria, Pinamalayan, Gloria, Bongabong, Roxas, Mansalay, Bulalacao, Magsaysay, San Jose, Pola, Soccoro</p>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>