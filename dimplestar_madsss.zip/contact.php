<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="" href="index.php">Home</a></li>
          <li><a class="" href="about.php">About Us</a></li>
          <li><a class="" href="terminal.php">Terminals</a></li>
          <li><a class="" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="active" href="contact.php">Contact</a></li>
          <li><a class="" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <section class="hero">
          <div class="container content">
            <h1>Contact Us</h1>
            <p class="sub">We’d love to hear from you. Send us a message and we’ll reply ASAP.</p>
          </div>
        </section>
        <section class="section">
          <div class="container grid grid-2">
            <div class="card">
              <h3 class="headline">Company Details</h3>
              <p class="muted">Dimple Star Transport<br>Block 1 Lot 10, Southpoint Subd.,<br>Brgy. Banay-Banay, Cabuyao, Laguna<br><br>Phone: 0929 209 0712</p>
              <div style="margin-top:12px">
                <strong>Date/Time:</strong>
                <div class="muted"><?php include_once("php_includes/date_time.php"); ?></div>
              </div>
            </div>
            <div class="card">
              <h3 class="headline">Message Form</h3>
              <form class="form" action="messageexec.php" method="POST">
                <div>
                  <label for="name">Name</label>
                  <input id="name" type="text" name="name" required>
                </div>
                <div>
                  <label for="email">Email</label>
                  <input id="email" type="email" name="email" placeholder="you@example.com" required>
                </div>
                <div>
                  <label for="subject">Subject</label>
                  <input id="subject" type="text" name="subject" required>
                </div>
                <div>
                  <label for="message">Message</label>
                  <textarea id="message" name="message" rows="5" required></textarea>
                </div>
                <div class="actions">
                  <button class="btn" type="submit" name="Submit" value="Submit">Submit</button>
                  <a class="btn btn-outline" href="index.php">Back to Home</a>
                </div>
              </form>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>