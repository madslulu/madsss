<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="" href="index.php">Home</a></li>
          <li><a class="" href="about.php">About Us</a></li>
          <li><a class="" href="terminal.php">Terminals</a></li>
          <li><a class="active" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
          <li><a class="" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <section class="hero">
          <div class="container content">
            <h1>Routes & Schedules</h1>
            <p class="sub">Check available routes and plan your trip ahead.</p>
          </div>
        </section>
        <section class="section">
          <div class="container">
            <div class="card">
              <h3 class="headline">Sample Routes</h3>
              <table class="table">
                <thead><tr><th>Origin</th><th>Destination</th><th>First Trip</th><th>Last Trip</th></tr></thead>
                <tbody>
                  <tr><td>San Lazaro</td><td>Alabang</td><td>04:30</td><td>20:30</td></tr>
                  <tr><td>Espana</td><td>Pinamalayan</td><td>05:00</td><td>18:30</td></tr>
                  <tr><td>Cabuyao</td><td>Gloria</td><td>06:00</td><td>19:00</td></tr>
                </tbody>
              </table>
              <p class="muted" style="margin-top:10px">*For the latest schedule, please contact our terminals.</p>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>