<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dimple Star Transport</title>
  <link rel="icon" href="images/icon.ico" type="image/x-con" />
  <link rel="stylesheet" href="style/new-style.css" />
</head>
<body>
  <header class="header">
      <div class="container header-inner">
        <a href="index.php" class="brand">
          <img src="images/logo.png" alt="Dimple Star Transport">
          <span>Dimple Star</span>
        </a>

      <nav class="nav">
        <ul>
          <li><a class="" href="index.php">Home</a></li>
          <li><a class="active" href="about.php">About Us</a></li>
          <li><a class="" href="terminal.php">Terminals</a></li>
          <li><a class="" href="routeschedule.php">Routes / Schedules</a></li>
          <li><a class="" href="contact.php">Contact</a></li>
          <li><a class="" href="book.php">Book Now</a></li>
        </ul>
      </nav>

      </div>
    </header>

        <section class="hero">
          <div class="container content">
            <h1>About Us</h1>
            <p class="sub">Our history, mission, and vision for better public transport.</p>
          </div>
        </section>
        <section class="section">
          <div class="container grid grid-2">
            <div class="card">
              <h3 class="headline">History</h3>
              <p class="muted">Photo taken on October 16, 1993. Napat Transit (now Dimple Star Transport) NVR-963 (fleet No. 800) going to Alabang under the LRT in Taft Ave., Ermita, Manila. In May 2004, Napat Transit became Dimple Star Transport.</p>
              <img src="images/oldbus.jpg" alt="Old bus" style="width:100%;border-radius:12px;margin-top:12px">
            </div>
            <div class="grid" style="gap:18px">
              <div class="card">
                <h3 class="headline">Mission</h3>
                <p>To provide superior transport service to Metro Manila and Mindoro Province commuters.</p>
              </div>
              <div class="card">
                <h3 class="headline">Vision</h3>
                <p>To lead the bus transport industry through innovative service to the riding public.</p>
              </div>
              <div class="card">
                <h3 class="headline">Connect</h3>
                <p class="muted">Like and follow us on Facebook.</p>
                <?php include_once("php_includes/fblike.php"); ?>
              </div>
            </div>
          </div>
        </section>

  <footer class="footer">
    <div class="container">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" />
      <p>&copy; 2025 Dimple Star Transport</p>
    </div>
  </footer>
</body>
</html>